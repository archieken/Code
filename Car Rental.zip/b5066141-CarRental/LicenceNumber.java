/**LicenceNumber stores the drivers initials, year licence was issued and a unique two digit serial number*/
public class LicenceNumber
{
    
  private String initials;
  private int year;
  private String serial;

  /**LicenceNumber stores the drivers initials, year licence was issued and a unique two digit serial number*/
    public LicenceNumber(String initials, int year, String serial)
    {   
        this.initials = initials;
        this.year = year;
        this.serial = serial;
    }
/**Overrides toString method. Returns a stringinitials, year and serial*/
    public String toString()
    {
         String name = initials + "-" + year + "-" + serial;
         return name;
    }
}
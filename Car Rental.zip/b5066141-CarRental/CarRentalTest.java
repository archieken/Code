import java.util.Date;
import java.util.Calendar;

public class CarRentalTest {
    private CarRentalTest() {  }

    public static void main(String[] args) {
        final CarRentalTest tcr = new CarRentalTest();

        tcr.testCarRental();

        tcr.testGetCar();

        tcr.testIssueCar();

        tcr.testTerminateRental();

    }

    /** Tests CarRentals constructor*/
    private void testCarRental(){
        final CarRental cr = new CarRental();

        //test to see if 30 small cars added to arraylist
        SmallCar sc = new SmallCar();
        Assertions.assertEqual(30, cr.availableCars(sc));

        //test to see if 20 large cars added to arraylist

        LargeCar lc = new LargeCar();
        Assertions.assertEqual(20, cr.availableCars(lc));
        System.out.println("testCarRental success");

    }

    /** Tests getCar method.*/
    private void testGetCar(){
        final CarRental cr = new CarRental();

        //normal conditions
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence person = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        Assertions.assertEqual("AK-2013-00", cr.getCar(person));
        System.out.println("testGetCar success");
    }

    /** Tests issue method.*/
    private void testIssueCar(){
        final CarRental cr = new CarRental();

        //normal conditions
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence person = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        SmallCar smallCar = new SmallCar();
        Assertions.assertTrue(cr.issueCar(person,smallCar));
        System.out.println("testIssueCar success");
    }

    /** Tests terminateRental.*/
    private void testTerminateRental(){

        final CarRental cr = new CarRental();

  
        
        //test smallCar. normal conditions
        String fullNameA = "Archie Kenwright";
        Date dateOfBirthA = new Date(1994, 04, 11);
        Date dateOfIssueA = new Date(2013, 02, 11);
        
        DrivingLicence personA = new DrivingLicence(fullNameA, dateOfBirthA, dateOfIssueA);
        SmallCar smallCar = new SmallCar();
        cr.issueCar(personA, smallCar);
        Assertions.assertEqual(0,cr.terminateRental(personA));

        //test largeCar. normal conditions
        String fullNameB = "George Kenwright";
        Date dateOfBirthB = new Date(1994, 04, 11);
        Date dateOfIssueB = new Date(2013, 02, 11);
        DrivingLicence personB = new DrivingLicence(fullNameB, dateOfBirthB, dateOfIssueB);
        LargeCar largeCar = new LargeCar();
        cr.issueCar(personB, largeCar);
        Assertions.assertEqual(0,cr.terminateRental(personB));
        
        
        System.out.println("testTerminateRental success");
    }

}
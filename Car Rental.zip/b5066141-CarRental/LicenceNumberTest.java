public class LicenceNumberTest {
    private LicenceNumberTest() {  }

    public static void main(String[] args) {
        final LicenceNumberTest tlic = new LicenceNumberTest();

        tlic.testToString();

    }

    private void testToString(){
        String initial = "AK";
        int year = 2013;
        String serial = "00";

        final LicenceNumber tl = new LicenceNumber(initial,year,serial);
        Assertions.assertEqual("AK-2013-00", tl.toString());
        System.out.println("testLicenceNumber success");
    }
}

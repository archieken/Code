public class NameTest {
    private NameTest() {  }
    
    public static void main(String[] args) {
        final NameTest np = new NameTest();
        
        np.testName();
        
        np.testGetFirstName();
        
        np.testGetLastName();
        
        np.testReturnInitials();
        
        np.testToString();
    }
              
    // testing the Name constructor
    private void testName() {
        final String firstName = "Archie";
        final String lastName = "Kenwright";
        
        // test normal case
        final Name p = new Name(firstName, lastName);
        
        Assertions.assertEqual(firstName, p.getFirstName());
        Assertions.assertEqual(lastName, p.getLastName());
        
        // test null firstName
        try {
            final Name nullName = new Name(null, lastName);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                NullPointerException.class, t);
        }
        
        // test empty name
        try {
            final Name emptyName = new Name("", lastName);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }
        
        // test null name
        try {
            final Name nullName = new Name(firstName, null);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                NullPointerException.class, t);
        }
        
        // test empty name
        try {
            final Name emptyName = new Name(firstName, "");
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }
        
        System.out.println("testName success");
    }
  
    private void testGetFirstName() {
        final Name p = new Name("Archie", "Kenwright");
        
        Assertions.assertEqual("Archie", p.getFirstName());
        
        System.out.println("testGetFirstName success");
    }
    
    private void testGetLastName() {
        final Name p = new Name("Archie", "Kenwright");
        
        Assertions.assertEqual("Kenwright", p.getLastName());
        
        System.out.println("testGetLastName success");
    }
    
    private void testReturnInitials(){
        final Name p = new Name("Archie", "Kenwright");
        
        Assertions.assertEqual("AK", p.returnInitials());
        
        System.out.println("testReturnInitials success");
    }
        
        private void testToString(){
        final Name p = new Name("Archie", "Kenwright");
        
        Assertions.assertEqual("Archie Kenwright", p.toString());
        
        System.out.println("testReturnToString success");
        }
}
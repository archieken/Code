public class LargeCarTest {
    private LargeCarTest() {  }

    public static void main(String[] args) {

        final LargeCarTest tlc = new LargeCarTest();

        // test constructor!!!!

        tlc.testDrive();
        tlc.testGetCapacity();
        tlc.testGetFuel();
        tlc.testIsTankFull();
        tlc.testIlcarRented();
        tlc.testAddFuel();
        tlc.testToString();

        
        //test UniqueLicence Generator
        tlc.testUniqueLicence();
        tlc.testFirstLicence();
        tlc.testSecondLicence();
        tlc.testThirdLicence();
        tlc.testFourthLicence();
        tlc.testLetterCycle();
        tlc.testNewLetterCycle();
        tlc.testExceedUnique();
    }

    private void testDrive()
    {
        final int distance = 60;

        // test normal case
        final LargeCar lc = new LargeCar();

        Assertions.assertEqual(750, lc.drive(distance));

        System.out.println("testDrive success");

    }

    public void testGetCapacity(){
        final LargeCar lc = new LargeCar();
        Assertions.assertEqual(49, lc.getCapacity());
        System.out.println("testCapacity success");
    }

    public void testGetFuel(){
        final LargeCar lc = new LargeCar();
        Assertions.assertEqual(49, lc.getFuel());
        System.out.println("testFuel success");
    }

    public void testIsTankFull(){

        final LargeCar lc = new LargeCar();
        Assertions.assertTrue(lc.isTankFull());
        System.out.println("testIsTankFull success");}

    public void testIlcarRented(){
        final LargeCar lc = new LargeCar();
        Assertions.assertFalse(lc.isCarRented());
        System.out.println("testIlcarRented success");}

    public void testAddFuel(){
        final LargeCar lc = new LargeCar();
        lc.addFuel(30);
        Assertions.assertEqual(0,lc.getFuel());
        System.out.println("testAddFuel success");}

    public void testToString()
    {
        final LargeCar lc = new LargeCar();
        Assertions.assertEqual("A000",lc.toString());
        System.out.println("testToString success");} 

    public void testUniqueLicence(){

        LargeCar lg = new LargeCar();

        Assertions.assertEqual("0002",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A0002",lg.getRegNumber());

        System.out.println("testFirstSerial success"); 

    }
    public void testFirstLicence(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(5);

        Assertions.assertEqual("0005",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A0005",lg.getRegNumber());

        System.out.println("testFirstLicence success"); 

    }
    public void testSecondLicence(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(10);

        Assertions.assertEqual("0011",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A0011",lg.getRegNumber());

        System.out.println("testSecondLicence success"); 

    }
    public void testThirdLicence(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(100);

        Assertions.assertEqual("0100",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A0100",lg.getRegNumber());

        System.out.println("testThirdLicence success"); 

    }
    public void testFourthLicence(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(1000);

        Assertions.assertEqual("1000",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A1000",lg.getRegNumber());

        System.out.println("testFourthLicence success"); 

    }
    public void testLetterCycle(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(9999);

        Assertions.assertEqual("9999",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("A9999",lg.getRegNumber());

        System.out.println("testLetterCycle success"); 

    }
    public void testNewLetterCycle(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(1000);

        Assertions.assertEqual("0000",lg.getFourDigits());
        Assertions.assertEqual("A",lg.getFirstLetter());
        Assertions.assertEqual("B0000",lg.getRegNumber());

        System.out.println("testNewLetterCycle success"); 

    }
    public void testExceedUnique(){
        LargeCar lg = new LargeCar();
        lg.setNumberCycle(10000);
        lg.setLetterCycle(25);

        Assertions.assertEqual("0000",lg.getFourDigits());
        Assertions.assertEqual("Z",lg.getFirstLetter());
        Assertions.assertEqual("Z0000",lg.getRegNumber());

        System.out.println("testExceedUnique success"); 

    }
}

public final class Name {
    
    private String firstName;
    private String lastName;  
    
    public Name(String firstName, String lastName) 
    {
        if (firstName.length() == 0){
            throw new IllegalArgumentException("empty string");
        }
        
        if (lastName.length() == 0){
            throw new IllegalArgumentException("empty string");
        }
        this.firstName=firstName;
        this.lastName=lastName;
    }

    /**Returns drivers first name.*/
    public String getFirstName()
    {
        return firstName;
    }
    
    /**Returns drivers last name.*/
    public String getLastName()
    {
        return lastName;
    }
    
    /**Sets drivers first name.*/
    public void setFirstName(String firstName) 
    { 
        this.firstName = firstName;
    }
    
    /**Sets drivers last name.*/
    public void setLastName(String lastName) 
    { 
        this.lastName = lastName;
    }
    
    /**Creates initials for the driver.*/
    public String returnInitials()
    {
       String firstInitial=""+firstName.charAt(0);
       String secondInitial=""+lastName.charAt(0);
       String initials= firstInitial.toUpperCase() + secondInitial.toUpperCase();
       return firstInitial+secondInitial;
    }
    
    /**Overrides toString. Returns fullname of driver*/
    public String toString() {
        return firstName + " " + lastName;
    }
    
}

/**Abstract class. 
 * Contains details about cars, including their fuel, rental status, and registration numbers. */

public abstract class AbstractCar implements Car
{
    // keeps record of instances of cars created. 
    //To ensure each instance has a different registration number and letter.
    private static int numberCycle = 0;
    private static int letterCycle = 0;
    
    private RegistrationNumber regNum;
    private int tankCapacity;
    private int fuel;
    private boolean tankFull;
    private boolean carRented;

    public AbstractCar()   
    {
        tankFull= true;
        carRented= false;
        regNum = getRegNumber();
    }
    
    /**a method to get the capacity in whole Litres of the car's fuel tank, which is 49 Litres
     * for a small car and 60 Litres for a large car**/

    public int getCapacity()
    {
        return tankCapacity;
    }

    /**a method to get the amount of fuel in whole Litres currently in the fuel tank**/
    public int getFuel()
    {
        return fuel;
    }

    /**a method that indicates whether the car's fuel tank is full or not**/
    public boolean isTankFull()
    {
        return tankFull;
    }

    /** a method that indicates whether the car is rented or not**/
    public boolean isCarRented()
    {
        return carRented;
    }

    /**a method to add a given number of whole Litres to the fuel tank and which,
     * after execution, indicates how much fuel was added to the tank**/
    public int addFuel(int f)
    {
        if (!isTankFull() && !isCarRented()){
            fuel+=f;
            return f;
        }
        else{
            return 0;
        }
    }
    
    //public abstract int drive(int distance);

    
     /**a method that makes the car available**/
    public void returnCar()
    {
        carRented = false;
    }

     /**a method that changes a cars status to rented**/
    public void rentCar()
    {
        carRented = true;
    }
    
    public void setFuel(int f)
    {
        fuel = f;
    }

    /**Generate a letter depending on the number of intances. It throws an error when there are no letters left.
       Used in getRegNumber.*/
    public String getFirstLetter()
    {      
        String letter = "";
        switch (letterCycle){
            case 0: letter="A"; break;
            case 1: letter="B"; break;
            case 2: letter="C"; break;
            case 3: letter="D"; break;
            case 4: letter="E"; break;
            case 5: letter="F"; break;
            case 6: letter="G"; break;
            case 7: letter="H"; break;
            case 8: letter="I"; break;
            case 9: letter="J"; break;
            case 10: letter="K"; break;
            case 11: letter="L"; break;
            case 12: letter="M"; break;
            case 13: letter="N"; break;
            case 14: letter="O"; break;
            case 15: letter="P"; break;
            case 16: letter="Q"; break;
            case 17: letter="R"; break;
            case 18: letter="S"; break;
            case 19: letter="T"; break;
            case 20: letter="U"; break;
            case 21: letter="V"; break;
            case 22: letter="W"; break;
            case 23: letter="X"; break;
            case 24: letter="Y"; break;
            case 25: letter="Z"; break;
            case 26:  throw new IllegalArgumentException("No unique registration numbers are left!");
        }
        return letter;
    }
    
    /** For each instance getFourDigits returns unique four digit number interating from 0000 to 9999. 
     * Then it changes the letter and restarts for 0000 again. Used in getRegNumber. */
    public String getFourDigits()
    {
        String num = "";
        if (numberCycle <10)
        {
            num  = "000"+numberCycle;
        }

        if (numberCycle >=10 && numberCycle <100)
        {
            num = "00"+numberCycle;
        }

        if (numberCycle >=100 && numberCycle<1000)
        {
            num = "0"+numberCycle;
        }

        if (numberCycle >=1000 && numberCycle <10000)
        {
           num = "" + numberCycle;
        }

        if (numberCycle >= 10000)
        {
            numberCycle = 0;
            letterCycle ++;
        }
        return num;
    }

      /**A method to get the car's registration number**/
    public RegistrationNumber getRegNumber()
    {
        String letter = getFirstLetter();
        String number = getFourDigits();
        RegistrationNumber regNum = new RegistrationNumber (letter, number);
        numberCycle ++;
        return regNum;
    }
    
    /**Methods used in testing**/
    public void setNumberCycle(int num){numberCycle=num;}
    public void setLetterCycle(int num){letterCycle=num;}
    
    
       /**Overrides the toString method. Returns the registration number**/
    public String toString()
    {
        return ""+ regNum; 
    }

    
}

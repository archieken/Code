public class SmallCar extends AbstractCar
{   
    /** Constructor, inherits variables from AbstractCar. Has a tankcapcity of 49 and fuel at 49 too.*/
    private int tankCapacity;
   private int fuel;
    public SmallCar()   
    {
        super();
        tankCapacity = 49;
        fuel = 49;
    }

    /** Method drives car. And returns the amount of fuel used. */
    public int drive(int distance)
    {
        int fuelUsed = 0;
        int fuelConsumption = 10; //for first 50km
        if (!isCarRented() && getFuel()>0)
        {
            fuelUsed = distance*fuelConsumption;
            int f = getFuel()- fuelUsed;
            setFuel(f);
        }

        return fuelUsed;
    }
}

import java.util.Date;
import java.util.Calendar;
/**DrivingLicence contains the drivers names, ages, the year the licence was issued, and wheter it is a full
   licence or not. It also generate a unique licence number. */
public final class DrivingLicence
{
    // Keeps a record of the number of DrivingLicence instances created.
    private static int instanceCounter = 0;

    private final Name fullName;
    private final Calendar born;
    private final Calendar issued;
    private final Calendar rightNow;
    private final boolean fullLicence;
    private final LicenceNumber uniqueLicence;

    public DrivingLicence(String fullName, Date dateOfBirth, Date dateOfIssue)
    {
        this.fullName = MakeFullName(fullName);
        rightNow = Calendar.getInstance();
        rightNow.setTime(new Date());
        
        
        born = Calendar.getInstance();
        born.setTime(dateOfBirth);
    
        
        
        issued = Calendar.getInstance();
        issued.setTime(dateOfIssue);
        
  
        fullLicence= true;
        uniqueLicence = getLicenceNumber();
    }

    /** MakeFullName method converts a String into a Name object*/
    public final Name MakeFullName(String name)
    {
        String[] names = name.split(" ");
        String firstName = names[0];
        String lastName = names[1];
        Name fullName = new Name(firstName, lastName);
        return fullName;
    }

    
    /** Returns name*/
    public final Name getFullName()
    {
        return fullName;
    }

    /** Returns date of birth*/
    public final Calendar getDateOfBirth()
    {
        return born;
    }

    /** Returns date of issue*/
    public final Calendar getDateOfIssue()
    {
        return issued;
    }

    /** Determines wheter the licence is full or not*/
    public final Boolean fullLicence()
    {
        return fullLicence;
    }

    /** Returns year the licence number was issued*/
    public final int yearOfIssue()
    {
        return issued.get(Calendar.YEAR);
    }
    
    /** Returns the age of the driver*/
     public final int getAge()
    {
        int age =  rightNow.get(Calendar.YEAR) - born.get(Calendar.YEAR);
        return age;
    }
    
    /** Returns the length of time in years that a driver has had their licence.
     * Called in drive method of car rental class.*/
    public final int getLenOfLic()
    {
        int lenOfLic =  rightNow.get(Calendar.YEAR) - yearOfIssue(); 
        return lenOfLic;
    }

    /** For each instance getTwoDigitNum returns unique two digit number interating from 00 to 99.
     * It throws an error when there are no unique numbers left. Used in getLicenceNumber. */
    public final String getTwoDigitNum(){

        String serial = "";
        if (instanceCounter >=0 && instanceCounter<10 )
        {
            serial = "0"+instanceCounter; 
        }
        
        if (instanceCounter>= 10 && instanceCounter<100)
        {
            serial = "" + instanceCounter;
        }
        
       if (instanceCounter >=100)
        {
            throw new IllegalArgumentException("No unique driving licences are left!");
        }
        return serial;
    }

    /** getLicenceNumber create a unique licence number*/
    public final LicenceNumber getLicenceNumber()
    {
        String initials = fullName.returnInitials();
        int year = yearOfIssue();
        String serial = getTwoDigitNum();
        LicenceNumber uniqueLicence = new LicenceNumber (initials, year, serial);
        instanceCounter ++;
        return uniqueLicence;
    }
    
    /**setInstanceCounter used for testing*/
    public static void setInstanceCounter(int instanceNum){ instanceCounter = instanceNum;}
    
    /**Override toString. returns drivers name and licence number*/
    public String toString()
    {
        return "" + fullName + ": " + uniqueLicence;
    }
}

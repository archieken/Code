import java.util.ArrayList;
import java.util.HashMap;

public final class CarRental
{
    private HashMap<DrivingLicence, AbstractCar> rentedCars;
    private ArrayList<AbstractCar> availableSmallCars;
    private ArrayList<AbstractCar> availableLargeCars;
    /**
     * Constructor for objects of class CarRental
     */
    public CarRental()
    {
        rentedCars = new HashMap<DrivingLicence,AbstractCar>();
        availableSmallCars = new ArrayList<AbstractCar>();
        availableLargeCars = new ArrayList<AbstractCar>();
        createCars();
    }

    /**Creates an ArrayList of cars containing 30 small cars and 20 large cars*/
    public final void createCars()
    {
        while (availableSmallCars.size()<30){
            AbstractCar currentSmallCar = new SmallCar(); 
            currentSmallCar.getRegNumber(); //generates unique registration number
            availableSmallCars.add(currentSmallCar);    
        }

        while (availableLargeCars.size()<20){
            AbstractCar currentLargeCar = new LargeCar();
            currentLargeCar.getRegNumber(); //generates unique registration number
            availableLargeCars.add(currentLargeCar);
        }
    }

    /**This method returns the number of cars of the specified type that are available to rent.*/
    public final int availableCars(AbstractCar typeOfCar)
    {
        if (typeOfCar instanceof SmallCar){
            return availableSmallCars.size();
        }

        if (typeOfCar instanceof LargeCar){
            return availableLargeCars.size();
        }
        
        return 0;
    }

    /**This method returns a collection of all the cars currently rented out.*/
    public final HashMap<DrivingLicence,AbstractCar> getRentedCars()
    {
        return rentedCars;
    }

    /**Given a person's driving licence, this method returns the car they are currently renting
    (if any)*/
    public final AbstractCar getCar(DrivingLicence drivingLicence)
    {
        AbstractCar currentCar = rentedCars.get(drivingLicence);
        if (currentCar == null) //checks that car is present
        {
          //  throw error
        }
        return currentCar;
    }

    /**This method determines whether the person is eligible to rent a car of the
    specified type and, if there is a car available, issues a car of the specified type.*/
    public final boolean issueCar(DrivingLicence person, AbstractCar typeOfCar)
    {
        AbstractCar personsCar = rentedCars.get(person); //check to see if client has rented a car
        boolean CarRented = false;
        if (typeOfCar instanceof SmallCar && availableSmallCars.size()>0 && personsCar==null && person.fullLicence() && person.getAge()>=21 && person.getLenOfLic() >=1) //if car small, available, and the person doesn't have a car, has a full licence, is over 21, has driven for over a year
        {
            for(AbstractCar currentCar: availableSmallCars)
            {
                if (currentCar.isTankFull())
                {
                    rentedCars.put(person, currentCar); 
                    currentCar.rentCar();
                    CarRented = true;
                }
            }
        }

        if (typeOfCar instanceof LargeCar && availableLargeCars.size()>0 && personsCar==null && person.fullLicence() && person.getAge()>=25 && person.getLenOfLic() >=5)
        {
            for(AbstractCar currentCar: availableLargeCars)
            {
                if (currentCar.isTankFull())
                {
                    rentedCars.put(person, typeOfCar);
                    CarRented = true;
                }
            }
        }
        return CarRented;
    }

    /**The method removes the record of the rental from the company's records and returns the amount of fuel in Litres required to fill the car's
    tank. The driver returning the car must either have returned the car with a full tank or will be liable for the number of Litres required to fill the tank. This method changes the status of the returned
    car to not rented.*/
    public final int terminateRental(DrivingLicence drivingLicence)
    {
        AbstractCar returnedCar = rentedCars.get(drivingLicence);
        int fullNeeded = 0;
        if(!returnedCar.isTankFull()){
            fullNeeded = returnedCar.getCapacity() - returnedCar.getFuel();
        }

        rentedCars.remove(returnedCar);
        returnedCar.returnCar();
        
        if (returnedCar instanceof SmallCar){
            availableSmallCars.add(returnedCar);
        }

        if (returnedCar instanceof LargeCar){
            availableLargeCars.add(returnedCar);
        }

        return fullNeeded;
    }
}
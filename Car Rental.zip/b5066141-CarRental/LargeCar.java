public class LargeCar extends AbstractCar
{   
    /** Constructor, inherits variables from AbstractCar. Has a tankcapcity of 60 and fuel at 60 too.*/
    private int tankCapacity;
   private int fuel;
    public LargeCar()   
    {
        super();
        tankCapacity = 60;
        fuel = 60;
    }
    
    
    /** Method drives car. And returns the amount of fuel used. */
    public int drive(int distance)
    {
        int fuelUsed = 0;
        int initialFuelConsumption = 10; //for first 50km
        int laterFuelConsumption = 15; //over 50km
        if (!isCarRented() && getFuel()>0)
        {
            if(distance <= 50){
                fuelUsed = distance*initialFuelConsumption;
                int f = getFuel()- fuelUsed;
                setFuel(f);
            }

        }

        if (distance>= 50){
            int extraDis = distance-50;
            fuelUsed = (distance*initialFuelConsumption)+(extraDis*laterFuelConsumption);
            int f = getFuel()- fuelUsed;
            setFuel(f);
        }
        return fuelUsed;
    }
}

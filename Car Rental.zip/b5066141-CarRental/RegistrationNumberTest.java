public class RegistrationNumberTest {
    private RegistrationNumberTest() {  }

    public static void main(String[] args) {
        
       final RegistrationNumberTest tlic = new RegistrationNumberTest();
        
       tlic.testRegistrationNumber();
        
       tlic.testGetLetter();
       
       tlic.testGetNumber();
    }
              
    /** Testing the RegistrationNumber constructor */
    private void testRegistrationNumber() {
        final String letter = "";
        final String number = "";
        
        // test normal case
        final RegistrationNumber lic = new RegistrationNumber(letter, number);

        // test null initials
        try {
            final RegistrationNumber nullRegistrationNumber = new RegistrationNumber(null, number);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                NullPointerException.class, t);
        }
        
        // test empty initials
        try {
            final RegistrationNumber emptyRegistrationNumber = new RegistrationNumber("", number);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }
        
         // test null number
        try {
            final RegistrationNumber nullRegistrationNumber = new RegistrationNumber(number,null);
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                NullPointerException.class, t);
        }
        
        // test empty number
        try {
            final RegistrationNumber emptyRegistrationNumber = new RegistrationNumber(number,"");
            Assertions.assertNotReached();
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }
        System.out.println("testRegistrationNumber success");
    }
    
    /** Testing to see if getLetter method works */
     private void testGetLetter() {
        final RegistrationNumber rn = new RegistrationNumber("A", "0000");
        
        Assertions.assertEqual("A", rn.getLetter());
        
        System.out.println("testGetLetter success");
    }
    
    /** Testing to see if getNumber method returns a four digit number. */
    public void testGetNumber(){
        final RegistrationNumber rn = new RegistrationNumber("A", "0000");
        
        Assertions.assertEqual("0000", rn.getNumber());
        
        System.out.println("testGetNumber success");
        
}
}

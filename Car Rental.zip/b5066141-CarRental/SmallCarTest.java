public class SmallCarTest {
    private SmallCarTest() {  }

    public static void main(String[] args) {

        final SmallCarTest tsc = new SmallCarTest();

// test constructor!!!!

        tsc.testDrive();
        tsc.testGetCapacity();
        tsc.testGetFuel();
        tsc.testIsTankFull();
        tsc.testIsCarRented();
        tsc.testAddFuel();
        tsc.testToString();
        
//test UniqueLicence Generator
        tsc.testUniqueLicence();
        tsc.testFirstLicence();
        tsc.testSecondLicence();
        tsc.testThirdLicence();
        tsc.testFourthLicence();
        tsc.testLetterCycle();
        tsc.testNewLetterCycle();
        tsc.testExceedUnique();
    }

    
    private void testDrive()
    {
        final int distance = 60;

        // test normal case
        final SmallCar sc = new SmallCar();

        Assertions.assertEqual(600, sc.drive(distance));

        System.out.println("testDrive success");

    }

    public void testGetCapacity(){
        final SmallCar sc = new SmallCar();
        Assertions.assertEqual(49, sc.getCapacity());
        System.out.println("testCapacity success");
    }

    public void testGetFuel(){
        final SmallCar sc = new SmallCar();
        Assertions.assertEqual(49, sc.getFuel());
        System.out.println("testFuel success");
    }

    public void testIsTankFull(){

        final SmallCar sc = new SmallCar();
        Assertions.assertTrue(sc.isTankFull());
        System.out.println("testIsTankFull success");}

    public void testIsCarRented(){
        final SmallCar sc = new SmallCar();
        Assertions.assertFalse(sc.isCarRented());
        System.out.println("testIsCarRented success");}

    public void testAddFuel(){
        final SmallCar sc = new SmallCar();
        sc.addFuel(30);
        Assertions.assertEqual(0,sc.getFuel());
        System.out.println("testAddFuel success");}

    public void testToString()
    {
        final SmallCar sc = new SmallCar();
        Assertions.assertEqual("A000",sc.toString());
        System.out.println("testToString success");} 
        
    public void testUniqueLicence(){
        
        SmallCar sm = new SmallCar();
        
        Assertions.assertEqual("0002",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A0002",sm.getRegNumber());
        
       System.out.println("testFirstSerial success"); 
 

    }
  
public void testFirstLicence(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(5);
        
        Assertions.assertEqual("0005",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A0005",sm.getRegNumber());
        
       System.out.println("testFirstLicence success"); 
 

    }
    public void testSecondLicence(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(10);
        
        Assertions.assertEqual("0011",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A0011",sm.getRegNumber());
        
       System.out.println("testSecondLicence success"); 
 

    }
    
public void testThirdLicence(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(100);
        
        Assertions.assertEqual("0100",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A0100",sm.getRegNumber());
        
       System.out.println("testThirdLicence success"); 
 

    }
    
    public void testFourthLicence(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(1000);
        
        Assertions.assertEqual("1000",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A1000",sm.getRegNumber());
        
       System.out.println("testFourthLicence success"); 
 

    }
    
    public void testLetterCycle(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(9999);
        
        Assertions.assertEqual("9999",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("A9999",sm.getRegNumber());
        
       System.out.println("testLetterCycle success"); 
 

    }
    
    public void testNewLetterCycle(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(1000);
        
        Assertions.assertEqual("0000",sm.getFourDigits());
        Assertions.assertEqual("A",sm.getFirstLetter());
        Assertions.assertEqual("B0000",sm.getRegNumber());
        
       System.out.println("testNewLetterCycle success"); 
 

    }
    
    public void testExceedUnique(){
        
        SmallCar sm = new SmallCar();
        sm.setNumberCycle(10000);
        sm.setLetterCycle(25);
        
        Assertions.assertEqual("0000",sm.getFourDigits());
        Assertions.assertEqual("Z",sm.getFirstLetter());
        Assertions.assertEqual("Z0000",sm.getRegNumber());
        
       System.out.println("testExceedUnique success"); 
 

    }
}

import java.util.Date;
import java.util.Calendar;

public class DrivingLicenceTest
{

    private DrivingLicenceTest() {  }

    public static void main(String[] args) {
        
        DrivingLicenceTest dlt = new DrivingLicenceTest();
        
        
         //test unique serialnumbers
        dlt.testFirstSerial();
        dlt.testFifthSerial();
        dlt.testTenthSerial();
        dlt.testLastSerial();
       // dlt.testExceededSerial();
        //dlt.testLargeSerial();
        
       
    }

    private void testFirstSerial()
    {
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        Assertions.assertEqual("01",nda.getTwoDigitNum());
        Assertions.assertEqual("Archie Kenwright",nda.toString());
        //Assertions.assertEqual("AK-1878-01",nda.getLicenceNumber());

        System.out.println("testFirstSerial success");

    }

    private void testFifthSerial()
    {
        DrivingLicence.setInstanceCounter(5);
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        Assertions.assertEqual("06",nda.getTwoDigitNum());
        Assertions.assertEqual("Archie Kenwright",nda.toString());
        // Assertions.assertEqual("AK--1878-06",nda.getLicenceNumber());

        System.out.println("testFifthSerial success");

    }

    private void testTenthSerial()
    {
        DrivingLicence.setInstanceCounter(10);
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        Assertions.assertEqual("11",nda.getTwoDigitNum());
        Assertions.assertEqual("Archie Kenwright",nda.toString());
        // Assertions.assertEqual("AK--1878-11",nda.getLicenceNumber());

        System.out.println("testTenthSerial success");
    }

    private void testLastSerial()
    {
        DrivingLicence.setInstanceCounter(98);
        String fullName = "Archie Kenwright";
        Date dateOfBirth = new Date(1994, 04, 11);
        Date dateOfIssue = new Date(2013, 02, 11);
        DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        Assertions.assertEqual("99",nda.getTwoDigitNum());
        Assertions.assertEqual("Archie Kenwright",nda.toString());
        //  Assertions.assertEqual("AK--1878-99",nda.getLicenceNumber());

        System.out.println("testLastSerial success");
    }

    private void testExceededSerial()
    {
        try {
            Assertions.assertNotReached();

            DrivingLicence.setInstanceCounter(99);
            String fullName = "Archie Kenwright";
            Date dateOfBirth = new Date(1994, 04, 11);
            Date dateOfIssue = new Date(2013, 02, 11);
            DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }

        System.out.println("testExceededSerial success");
    }

    private void testLargeSerial()
    {
        try {
            Assertions.assertNotReached();

            DrivingLicence.setInstanceCounter(1000);
            String fullName = "Archie Kenwright";
            Date dateOfBirth = new Date(1994, 04, 11);
            Date dateOfIssue = new Date(2013, 02, 11);
            DrivingLicence nda = new DrivingLicence(fullName, dateOfBirth, dateOfIssue);
            System.out.println(nda.getTwoDigitNum());
            System.out.println(nda.toString());
            System.out.println(nda.getLicenceNumber());
        } catch (Throwable t) {
            Assertions.assertExpectedThrowable(
                IllegalArgumentException.class, t);
        }
        System.out.println("testLargeSerial success");
    }
}

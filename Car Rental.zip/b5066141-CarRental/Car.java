/**Interface for Cars.*/
public interface Car
{
    public RegistrationNumber getRegNumber();
    public int getCapacity();
    public int getFuel();
    public boolean isTankFull();
    public boolean isCarRented();
    public int addFuel(int f);
    public int drive(int distance);
}

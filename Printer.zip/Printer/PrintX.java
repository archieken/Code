public class PrintX extends Thread implements Runnable {

	private BinarySemaphore mutex;
	private BinarySemaphore mutex2;
	private Semaphore counter;

	public PrintX(BinarySemaphore mutex,BinarySemaphore mutex2, Semaphore counter)
	{
		this.mutex = mutex;
		this.mutex2 = mutex2;
		this.counter = counter;

	}

	public void run(){
		while (true){
			try {

				//Method will not run unless counter && mutex2 equal 1.
				mutex.P();
				counter.P();

				//Sleeps for a random amount of time.
				sleep((long) Math.random() * 1000);
				System.out.println("X");

				//Increments Mutex2, letting the thread PrintY run
				mutex2.V();} 

			catch (InterruptedException e) {
				e.printStackTrace();}
		}
	}	
}

public class Program {

	public static void main (String[] args) throws InterruptedException
	{
		//Lock for thread x
		BinarySemaphore mutex= new BinarySemaphore(1);
		//Lock for thread y
		BinarySemaphore mutex2= new BinarySemaphore(0);
		//Lock for thread z
		Semaphore counter = new Semaphore(0);

		Thread x = new PrintX(mutex, mutex2, counter);
		Thread y = new PrintY(mutex, mutex2, counter);
		Thread z = new PrintZ(counter);
		x.start();
		y.start();
		z.start();

		//Lets program run for 3 milliseconds then quits.
		Thread.sleep(3);
		System.exit(0);

	}

}
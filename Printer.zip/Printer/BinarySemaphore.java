public class BinarySemaphore extends Semaphore {


	// BinarySemaphore takes two arguments 0 and 1.
	public BinarySemaphore (int initial){

		value = (initial>0) ? 1 : 0;
	}

}
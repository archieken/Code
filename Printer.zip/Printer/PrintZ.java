public class PrintZ extends Thread implements Runnable {

	public Semaphore counter = new Semaphore(0);

	public PrintZ(Semaphore counter){
		this.counter = counter;
	}

	public void run(){
		while (true){

			try{

				//Sleeps for a random amount of time.
				sleep((long) Math.random() * 1000);
				System.out.println("Z");

				//Increments counter. Letting threads PrintZ and PrintY run.
				counter.V();

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

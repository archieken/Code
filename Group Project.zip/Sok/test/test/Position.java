package test;

public class Position {

	private int y;
	private int x;

	public int getY() {
		return y;
	}

	public int getX() {
		return x;
	}

	public Position(int y, int x) {
		this.y = y;
		this.x = x;
	}

	@Override
	public int hashCode() {
		return y * 1000 + x;
	}

	@Override
	public boolean equals(Object that) {
		if (that == null)
			return false;
		if (that == this)
			return true;
		if (this.getClass() != that.getClass())
			return false;
		Position thatPosition = (Position) that;
		if (this.hashCode() == thatPosition.hashCode())
			return true;
		return ((this.y == thatPosition.getY()) && (this.x == thatPosition
				.getX()));
	}

}

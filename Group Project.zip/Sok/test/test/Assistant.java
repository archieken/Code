/**
* An instance of Assistant is created when appropriate input is received by  GamePanel. The tileMap 
* object input is stored within the class. The string input is parsed to interpret the current state of the game
* at point of user input. This allows the getFile method instantiate the data structures to store the character set.
* After solving the level, the returned data structure of directions can be iterated over else where to allow the game
* to animate the solution for the user. 
* @author Group5
*
*/
package test;

import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Assistant {

	private static HashSet<Position> walls = new HashSet<Position>();
	private static HashSet<Position> goals = new HashSet<Position>();
	private static HashSet<Position> boxes = new HashSet<Position>();
	Stack<Direction> dir = new Stack<Direction>();
	private TileMap tl;
	private JFrame window;

	private static int manhattan(Position a, Position b) {
		return Math.abs(a.getY() - b.getY()) + Math.abs(a.getX() - b.getX());
	} // returns manhattan distance

	private static Comparator<Node> ASTAR = new Comparator<Node>() {
		public int compare(Node a, Node b) {
			return (int) ((a.getCost() + getManhattan(a.getState())) - (b
					.getCost() + getManhattan(b.getState())));
		}
	};
	/**
	* Assistant created with tileMap and string input. String is used to getFile and return an instance of AStarSearch
	* which is stored on a Queue.
	* JOptionPane is used to display Queue to the user is solution is found, and an appropriate message if not found.
	* @param String file, TileMap tileMap
	* @return LogicChecker instantiated with level character set
	*/

	public Assistant(String file, TileMap tileMap, JFrame window) {
		tl = tileMap;
		tl.setAssistant(this);
		this.window = window;
		Queue<Direction> directions = getAStarSearch(getFile(file));
		if (!(directions == null)) {
			dir.addAll(directions);
			JOptionPane.showMessageDialog(this.window,
					"A* search & manhattan heuristic :" + directions.size()
							+ " player moves\n" + directions);// system out
																// print for
																// debugging
		} else {
			JOptionPane.showMessageDialog(this.window, "No Possible Solution");
		}
	}
	/**
	* Reads lines from input string, storing each in the data structure
	* @param String filename
	* @return LogicChecker instantiated with level character set
	*/

	public LogicChecker getFile(String filename) {
		walls = new HashSet<Position>();
		goals = new HashSet<Position>();
		boxes = new HashSet<Position>();
		Scanner scanner = new Scanner(filename);
		scanner.nextLine(); // columns not required for assistant function
		int rows = Integer.parseInt(scanner.nextLine());
		Position player = null;
		for (int y = 0; y < rows; y++) {
			String line = scanner.nextLine();
			for (int x = 0; x < line.length(); x++) {
				Position object = new Position(y, x);
				switch (line.charAt(x)) {
				case '@':
					player = object;
					break; // player
				case '+':
					player = object;
					goals.add(object);
					break; // player on a goal
				case '#':
					walls.add(object);
					break; // walls
				case '.':
					goals.add(object);
					break; // goal
				case '*':
					goals.add(object);
					boxes.add(object);
					break; // box on a goal
				case '$':
					boxes.add(object);
					break; // box
				}
			}
		}
		scanner.close();
		return new LogicChecker(walls, new State(boxes, player), goals);
	}
	/**
	* Runs an instance of A* search, with fringe maintained as Priority Queue.
	* @param LogicChecker checkLogic object
	* @return Queue of type Direction showing moves to terminal state or null if no solution found
	*/	

	public Queue<Direction> getAStarSearch(LogicChecker checkLogic) {
		Node initialNode = new Node(checkLogic.checkInitialState());
		Set<State> explored = new HashSet<State>();
		Queue<Node> fringe = new PriorityQueue<Node>(ASTAR);
		fringe.add(initialNode);
		while (fringe.isEmpty() == false) {
			Node node = fringe.remove();
			if (checkLogic.checkSolved(node.getState()))
				return getSolution(node);
			if (checkLogic.checkDeadlock(node.getState()) == false) {
				explored.add(node.getState());
				LinkedList<Direction> actions = checkLogic.checkActions(node
						.getState());
				for (Direction action : actions) {
					Node child = getChild(node, action);
					if (child != null && child.getState() != null) {
						if (!explored.contains(child.getState())
								&& !fringe.contains(child))
							fringe.add(child);
						else
							for (Node next : fringe)
								if (next == child
										&& child.getCost() < next.getCost())
									next = child;
					}
				}
			}
		}
		return null;
	}
	/**
	* 
	* @param a Node object
	* @return Solution as queue of directions
	*/

	private Queue<Direction> getSolution(Node givenNode) {
		Queue<Direction> directions = new LinkedList<Direction>();
		while (givenNode.getAncestor() != null) {
			directions.add(givenNode.getDirection());
			givenNode = givenNode.getAncestor();
		}
		return directions;
	}

	@SuppressWarnings("unchecked")
	/**
	* 
	* @param a Node object
	* @param Direction action
	* @return Node object, a child of given Node object
	*/

	private Node getChild(Node forGivenNode, Direction action) {
		HashSet<Position> boxes = (HashSet<Position>) forGivenNode.getState()
				.getBoxes().clone();
		int y = forGivenNode.getState().getPlayer().getY();
		int x = forGivenNode.getState().getPlayer().getX();
		int cost = forGivenNode.getCost() + 1; // child cost increased by one
		Position playerA = forGivenNode.getState().getPlayer();
		if (action == Direction.UP) {
			playerA = new Position(y - 1, x);
			if (boxes.contains(playerA)) {
				boxes.remove(playerA);
				boxes.add(new Position(y - 2, x));
			}
		} else if (action == Direction.DOWN) {
			playerA = new Position(y + 1, x);
			if (boxes.contains(playerA)) {
				boxes.remove(playerA);
				boxes.add(new Position(y + 2, x));
			}
		} else if (action == Direction.LEFT) {
			playerA = new Position(y, x - 1);
			if (boxes.contains(playerA)) {
				boxes.remove(playerA);
				boxes.add(new Position(y, x - 2));
			}
		} else if (action == Direction.RIGHT) {
			playerA = new Position(y, x + 1);
			if (boxes.contains(playerA)) {
				boxes.remove(playerA);
				boxes.add(new Position(y, x + 2));
			}
		}
		return new Node(new State(boxes, playerA), forGivenNode, cost, action);
	}

	public static double getManhattan(State givenState) {
		HashSet<Position> boxes = givenState.getBoxes();
		double heuristic = 0;
		for (Position box : boxes) {
			heuristic += manhattan(box, givenState.getPlayer());
			for (Position goal : goals)
				heuristic += manhattan(box, goal);
		}
		return heuristic;
	}
}

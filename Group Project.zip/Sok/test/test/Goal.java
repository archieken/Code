/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The Goal class creates a new Goal object.
 * 
 * @author Group5 
 * @version 5/3/2016
 */
package test;

import java.awt.*;

public class Goal {
	private int x;
	private int y;
	private TileMap tileMap;
	private int tileSize;

	public Goal(TileMap tl) {
		tileMap = tl;
		tileSize = tl.getTileSize();
	}

	public void setx(int x) {
		this.x = x;
	}

	public void sety(int y) {
		this.y = y;
	}
	/**
	 *return x 
	 */
	public int getx() {
		return x;
	}
	/**
	 *return y 
	 */
	public int gety() {
		return y;
	}
	/** Draw method**/
	public void draw(Graphics2D g, Image imgoal) {

		g.drawImage(imgoal, y * tileSize, x * tileSize, null);
	}

}

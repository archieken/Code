/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The GamePanel class creates the game panel that will have the game.
 * It draws the main menu and handles the different options.
 * 
 * The class is also responsible for listening and handling the keyboard input
 * 
 * @author Group5 
 * @version 5/3/2016
 */
package test;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.NoSuchElementException;

public class GamePanel extends JPanel implements Runnable, KeyListener {

	// FIELDS
	public int WIDTH = 1152;
	public int HEIGHT = 648;
	private Thread thread;
	private boolean running;
	private BufferedImage image;
	private Graphics2D g, g4;
	private TileMap tileMap;
	private boolean mainmenu;
	private Image menu;
	private int m = 1;
	private boolean done = false;
	private JFrame window;
	volatile boolean updated;
	JFileChooser chooser;

	// CONSTRUCTOR
	public GamePanel(JFrame window) {
		super();
		this.window = window;
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setFocusable(true);
		requestFocus();
		addKeyListener(this);
	}

	// FUNCTIONS
	@Override
	public void addNotify() {
		super.addNotify();
		if (thread == null) {
			thread = new Thread(this);
			thread.start();
		}

	}

	@Override
	public void run() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		mainmenu = true;
		int l = 1;
		try {
			menu = ImageIO.read(new File("test/test/graphics/menu-1.jpg"));
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		g4 = (Graphics2D) getGraphics();
		g4.drawImage(menu, 0, 0, null);
		while (!done) {
			while (mainmenu) {
				try {
					if (m == 1) {
						menu = ImageIO.read(new File(
								"test/test/graphics/menu-1.jpg"));
					}
					if (m == 2) {
						menu = ImageIO.read(new File(
								"test/test/graphics/menu-2.jpg"));
					}
					if (m == 3) {
						menu = ImageIO.read(new File(
								"test/test/graphics/menu-3.jpg"));
					}
					g4.drawImage(menu, 0, 0, null);

				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}

			// GAME LOOP
			while (!mainmenu) {
				if (m == 1) {
					running = true;
					if (l == 1) {
						tileMap = new TileMap("test/test/levels/level1.txt", 28);
					}
					if (l == 2) {
						tileMap = new TileMap("test/test/levels/level2.txt", 28);
					}
					if (l == 3) {
						tileMap = new TileMap("test/test/levels/level3.txt", 28);
					}
					if (l == 4) {
						tileMap = new TileMap("test/test/levels/level4.txt", 28);
					}
					if (l == 5) {
						tileMap = new TileMap("test/test/levels/level5.txt", 28);
					}
					if (l == 6) {
						tileMap = new TileMap(chooser.getSelectedFile()
								.toString(), 28);

					}
					setPreferredSize(new Dimension(tileMap.mapWidth * 28,
							tileMap.mapHeight * 28));
					window.setSize(new Dimension(tileMap.mapWidth * 28,
							tileMap.mapHeight * 28));
					window.revalidate(); // Adjust the dimension of the window
											// based on each level.
					window.pack();
					while (running) {
						gameRender();
						gameDraw();
						Image img1 = null;
						if (tileMap.isComplete()) {
							Graphics2D g3 = (Graphics2D) getGraphics();
							if (l < 5) {
								try {
									img1 = ImageIO
											.read(new File(
													"test/test/graphics/levelcomp.jpg"));
									g3.scale(0.5, 0.5);
									g3.drawImage(img1, tileMap.mapWidth * 8,
											tileMap.mapHeight * 10, null);

									Thread.sleep(1000);
								} catch (IOException | InterruptedException e) {
									e.printStackTrace();
								}
							} else {
								try {
									img1 = ImageIO.read(new File(
											"test/test/graphics/gamecomp.png"));
								} catch (IOException e) {
									e.printStackTrace();
								}
								g3.scale(0.5, 0.5);
								g3.drawImage(img1, tileMap.mapWidth * 8,
										tileMap.mapHeight * 10, null);
								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}
							if (l < 5) {
								l++;
							} else {
								running = false;
								setPreferredSize(new Dimension(WIDTH, HEIGHT));
								window.pack();
								mainmenu = true;
							}

							running = false;
						}
					}
				}
				if (m == 2) {
					chooser = new JFileChooser(); // File chooser
					FileNameExtensionFilter filter = new FileNameExtensionFilter(
							"Levels", "txt");
					chooser.setFileFilter(filter);
					int returnVal = chooser.showOpenDialog(getParent());
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						System.out.println("You chose to open this file: "
								+ chooser.getSelectedFile().getName());
						try {
							Tester tester = new Tester(chooser
									.getSelectedFile().toString());
							if (tester.getTest() == 1) {
								m = 1; // Passes the file for testing, if it is
										// successful it
								l = 6; // creates the level.
							} else {
								JOptionPane.showMessageDialog(window,
										"Incorrect Level");
								chooser.cancelSelection();
							}
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

					else {
						mainmenu = true;
						m = 1;
					}

				}
				if (m == 3) {
					try {
						menu = ImageIO.read(new File(
								"test/test/graphics/info.jpg"));
					} catch (IOException e) {
						e.printStackTrace();
					}
					g4.drawImage(menu, 0, 0, null);

				}
			}
		}
	}
	/** tilemap draw method**/
	public void gameRender() {
		tileMap.draw(g4);
	}
	/** Draw method**/
	public void gameDraw() {
		Graphics2D g2 = (Graphics2D) getGraphics();
		g2.drawImage(image, 0, 0, null);
		g2.dispose();
	}

	@Override
	/**
	 * Key event handling 
	 * **/
	public void keyPressed(KeyEvent key) {
		int code = key.getKeyCode();
		if (code == KeyEvent.VK_UP) {
			if (running) {
				if (!tileMap.getRedo().isEmpty()) {
					tileMap.clearRedo();

				}
				tileMap.add = true;
				tileMap.moveUp();

			}
			if (!running && mainmenu && m > 1) {
				m--;
				updated = true;
			}

		}
		if (code == KeyEvent.VK_RIGHT) {
			if (running) {
				if (!tileMap.getRedo().isEmpty()) {
					tileMap.clearRedo();

				}
				tileMap.add = true;
				tileMap.moveRight();
			}
		}
		if (code == KeyEvent.VK_DOWN) {
			if (running) {
				if (!tileMap.getRedo().isEmpty()) {
					tileMap.clearRedo();

				}
				tileMap.add = true;
				tileMap.moveDown();
			}
			if (!running && mainmenu && m < 3) {
				m++;
				updated = true;
			}
		}
		if (code == KeyEvent.VK_LEFT) {
			if (running) {
				if (!tileMap.getRedo().isEmpty()) {
					tileMap.clearRedo();
				}
				tileMap.add = true;
				tileMap.moveLeft();
			}
		}
		if (code == KeyEvent.VK_SPACE) {
			if (running) {
				tileMap.add = false;
				tileMap.useUndo();
			}
		}
		if (code == KeyEvent.VK_SHIFT) {
			if (running) {
				tileMap.add = false;
				tileMap.useRedo();
			}
		}
		if (code == KeyEvent.VK_ENTER) {
			if (mainmenu) {
				mainmenu = false;
			}

		}
		if (code == KeyEvent.VK_K) {
			if (running) {
				tileMap.useAssistant();
			}

		}
		if (code == KeyEvent.VK_A) {
			try {
				Assistant a = new Assistant(tileMap.toString(), tileMap, window);
			} catch (NumberFormatException | NoSuchElementException e) {
				e.printStackTrace();
			}

		}
		if (code == KeyEvent.VK_R) {
			window.dispose();
			String[] args = null;
			try {
				Game.main(args);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (code == KeyEvent.VK_ESCAPE) {
			if (!running) {
				m = 1;
				mainmenu = true;
				updated = true;

			}
			if (running) {
				m = 1;
				mainmenu = true;
				running = false;
				updated = true;
			}
			setPreferredSize(new Dimension(WIDTH, HEIGHT));
			window.pack();

		}
		if (code == KeyEvent.VK_S) {
			System.out.println(tileMap.toString());
			try (PrintWriter output = new PrintWriter(
					"test/test/currentGame.txt")) {
				output.println(tileMap);
				output.close();
			}

			catch (IOException e) {
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

}

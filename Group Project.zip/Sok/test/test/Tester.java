package test;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Tester {
	private int count = 0;
	private String[][] map;

	public Tester(String level) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(level));
		Scanner sc = new Scanner(new FileReader(level));
		int max = 0;
		int mapWidth = 0;
		int mapHeight = 0;
		while (sc.hasNextLine()) {
			int test = sc.nextLine().length();
			mapHeight++;
			max = test;
			if (max >= mapWidth) {
				max++;
				mapWidth = max - 1;
			}
		}

		sc.close();
		map = new String[mapHeight][mapWidth];
		for (int row = 0; row < mapHeight; row++) {
			String line = br.readLine();
			String[] tokens = line.split("", -1);
			for (int col = 0; col < mapWidth; col++) {
				map[row][col] = tokens[col];
				if (map[row][col].equals("@")) {
					count++;
				}
			}
		}
		br.close();
	}

	int getTest() {
		return count;
	}
}

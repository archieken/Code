/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The Game class creates a new JFrame and a new GamePanel
 * that will have the game.
 * 
 * @author Group5 
 * @version 5/3/2016
 */

package test;

import java.awt.GridLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Game {

	public static void main(String[] args) throws InterruptedException {
		JFrame window = new JFrame("Sokoban");
		GamePanel gamepanel = new GamePanel(window);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setContentPane(gamepanel); // Adds the gamepanel to the frame
		window.pack(); // Causes this Window to be sized to fit the preferred
						// size and layouts of its subcomponents.
		window.setVisible(true);
	}
}
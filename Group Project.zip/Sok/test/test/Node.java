/**
* Class node maintains information such as its state, parent, cost and direction.
* @Param State state, Node parent, int cost, Direction move,
* @author Group5
*/
package test;

public class Node {

	private Node ancestor;
	private State state;
	private int cost;
	private Direction direction;
	/**
	* Getter method for Node ancestor
	* @return Node ancestor
	*/

	public Node getAncestor() {
		return ancestor;
	}
	/**
	* Getter method for State state
	* @return State state
	*/

	public State getState() {
		return state;
	}
	/**
	* Getter method for int cost
	* @return int cost
	*/

	public int getCost() {
		return cost;
	}
	/**
	* Getter method for Direction direction
	* @return Direction direction
	*/

	public Direction getDirection() {
		return direction;
	}
	/**
	* Contructor to construct a Node. This is an overloaded constructor
	* @param State state
	*/

	public Node(State state) { // constructor overloading
		this.state = state;
		this.ancestor = null;
		this.cost = 0;
		this.direction = null;
	}
	/**
	* Constructor to construct a Node. 
	* @param State state
	* @param Node parent
	* @param int cost
	* @param Direction move
	*/

	public Node(State state, Node parent, int cost, Direction move) {
		this.state = state;
		this.ancestor = parent;
		this.cost = cost;
		this.direction = move;
	}

	@Override/**
	* Overriden equals method checks for object equality
	*/

	public boolean equals(Object that) {
		return (this.state == ((Node) that).state);
	}

}

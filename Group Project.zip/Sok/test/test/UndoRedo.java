package test;

import java.util.Stack;

public class UndoRedo {
	private Stack<String> undo;
	private Stack<String> redo;
	private TileMap tl;
	private String move;

	public UndoRedo(TileMap tl) {
		this.tl = tl;
		undo = new Stack<String>();
		redo = new Stack<String>();
	}

	public Stack<String> getStack() {
		return undo;
	}

	public Stack<String> getRedo() {
		return redo;
	}

	public void addUndo(String move) {
		undo.push(move);
	}

	public void useUndo() {
		if (!undo.isEmpty()) {
			move = undo.pop();
			if (move.equals("left")) {
				tl.updateMap("left");
			}
			if (move.equals("leftbox")) {
				tl.updateMap("leftbox");
			}
			if (move.equals("right")) {
				tl.updateMap("right");
			}
			if (move.equals("rightbox")) {
				tl.updateMap("rightbox");
			}
			if (move.equals("up")) {
				tl.updateMap("up");
			}
			if (move.equals("upbox")) {

				tl.updateMap("upbox");
			}
			if (move.equals("down")) {
				tl.updateMap("down");
			}
			if (move.equals("downbox")) {

				tl.updateMap("downbox");
			}
			addRedo(move);
		}
	}

	public void useRedo() {
		if (!redo.isEmpty()) {
			move = redo.pop();
			if (move.equals("left")) {
				tl.moveLeft();
			}
			if (move.equals("leftbox")) {
				tl.moveLeft();
			}
			if (move.equals("right")) {
				tl.moveRight();
			}
			if (move.equals("rightbox")) {
				tl.moveRight();
			}
			if (move.equals("up")) {
				tl.moveUp();
			}
			if (move.equals("upbox")) {

				tl.moveUp();
			}
			if (move.equals("down")) {
				tl.moveDown();
			}
			if (move.equals("downbox")) {

				tl.moveDown();
			}
			addUndo(move);
		}

	}

	public void addRedo(String move) {
		redo.push(move);
	}

	public void clearRedo() {
		if (!redo.isEmpty()) {
			redo.clear();
		}
	}
}

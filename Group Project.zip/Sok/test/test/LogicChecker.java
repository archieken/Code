/**
 * LogicChecker class stores State initial state and private HashSets for walls and goals,
 * returns a LogicChecker to the Assistant. 
 * @author Group5
 */
package test;

import java.util.HashSet;
import java.util.LinkedList;

public class LogicChecker {

	private State initialState;
	private HashSet<Position> walls;
	private HashSet<Position> goals;
	/**
	 * Constructor intanstiates a LogicChecker object with arguments of initial state, walls and goals.
	 * @param HashSet of Position of walls
	 * @param HashSet of Position of goals
	 * @param State initial state
	 * @return initialState
	 */
	public LogicChecker(HashSet<Position> walls, State initialState,
			HashSet<Position> goals) {
		this.initialState = initialState;
		this.walls = walls;
		this.goals = goals;
	}
	/**
	 * Returns initial state
	 * @return initialState
	 */

	public State checkInitialState() {
		return initialState;
	}
	/**
	 * For given state, returns if boxes are in goals
	 * @return boolean to indicate if game is solved
	 */

	public boolean checkSolved(State forGivenState) {
		for (Position box : forGivenState.getBoxes())
			if (!goals.contains(box))
				return false;
		return true;
	}
	/**
	 * For given state, returns if situation is a deadlock
	 * @return boolean to indicate if game is deadlocked
	 */


	public boolean checkDeadlock(State forGivenState) {
		for (Position box : forGivenState.getBoxes()) {
			int y = box.getY();
			int x = box.getX();
			Position current = new Position(y, x);
			Position up = new Position(y - 1, x);
			Position upup = new Position(y - 2, x);
			Position upleft = new Position(y - 1, x - 1);
			Position upright = new Position(y - 1, x + 1);
			Position left = new Position(y, x - 1);
			Position leftleft = new Position(y, x - 2);
			Position right = new Position(y, x + 1);
			Position rightright = new Position(y, x + 2);
			Position down = new Position(y + 1, x);
			Position downdown = new Position(y + 2, x);
			Position downright = new Position(y + 1, x + 1);
			Position downleft = new Position(y + 1, x - 1);
			if (goals.contains(current) == false) {
				if (walls.contains(up) && walls.contains(left))
					return true; // UP+LEFT
				if (walls.contains(up) && walls.contains(right))
					return true; // UP+RIGHT
				if (walls.contains(down) && walls.contains(left))
					return true; // DOWN+LEFT
				if (walls.contains(down) && walls.contains(right))
					return true; // BOTTOM+RIGHT
				if (walls.contains(upleft) && walls.contains(up)
						&& walls.contains(upright) && walls.contains(leftleft)
						&& walls.contains(rightright)
						&& goals.contains(left) == false
						&& goals.contains(right) == false)
					return true; // UP+SIDES
				if (walls.contains(downleft) && walls.contains(down)
						&& walls.contains(downleft) && walls.contains(leftleft)
						&& walls.contains(rightright)
						&& goals.contains(left) == false
						&& goals.contains(right) == false)
					return true; // BOTTOM+SIDES
				if (walls.contains(upleft) && walls.contains(left)
						&& walls.contains(downleft) && walls.contains(upup)
						&& walls.contains(downdown)
						&& goals.contains(up) == false
						&& goals.contains(down) == false)
					return true; // LEFT+UPDOWN
				if (walls.contains(upright) && walls.contains(rightright)
						&& walls.contains(downright) && walls.contains(upup)
						&& walls.contains(downdown)
						&& goals.contains(up) == false
						&& goals.contains(down) == false)
					return true; // RIGHT+UPDOWN
			}
		}
		return false;
	}
	/**
	 * For given state, returns a LinkedList of possible Direction actions
	 * @return LinkedList of Direction of possible actions
	 */
	public LinkedList<Direction> checkActions(State forGivenState) {
		LinkedList<Direction> actions = new LinkedList<Direction>();
		int y = forGivenState.getPlayer().getY();
		int x = forGivenState.getPlayer().getX();
		HashSet<Position> boxes = forGivenState.getBoxes();
		Position player = new Position(y - 1, x);
		Position box = new Position(y - 2, x);
		if (!walls.contains(player)
				&& !(boxes.contains(player) && (boxes.contains(box) || walls
						.contains(box))))
			actions.add(Direction.UP);
		player = new Position(y, x + 1);
		box = new Position(y, x + 2);
		if (!walls.contains(player)
				&& !(boxes.contains(player) && (boxes.contains(box) || walls
						.contains(box))))
			actions.add(Direction.RIGHT);
		player = new Position(y + 1, x);
		box = new Position(y + 2, x);
		if (!walls.contains(player)
				&& !(boxes.contains(player) && (boxes.contains(box) || walls
						.contains(box))))
			actions.add(Direction.DOWN);
		player = new Position(y, x - 1);
		box = new Position(y, x - 2);
		if (!walls.contains(player)
				&& !(boxes.contains(player) && (boxes.contains(box) || walls
						.contains(box))))
			actions.add(Direction.LEFT);
		return actions;
	}
}

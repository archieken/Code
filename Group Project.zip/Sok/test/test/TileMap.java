/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The TileMap class creates and draws the level based on a text file.
 * It draws the elements of the game.
 * It is also responsible for the movement.
 * 
 * The class is also responsible for listening and handling the keyboard input
 * 
 * @author Group5 
 * @version 5/3/2016
 */
package test;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

import javax.imageio.ImageIO;

import java.awt.*;

public class TileMap {
	private int x;
	private int y;
	private int tileSize;
	private String[][] map;
	protected int mapWidth;
	protected int mapHeight;
	private Player pl;
	private Box box;
	private Goal goal;
	private ArrayList<Goal> goals = new ArrayList<Goal>();
	private BufferedReader br;
	private UndoRedo undred;
	boolean complete = false;
	boolean add = true;
	Image imwall = null;
	Image imbox = null;
	Image imfloor = null;
	Image imgoal = null;
	Image implayer = null;
	private Assistant assist;
	/** Constructor **/
	public TileMap(String s, int tileSize) {
		this.tileSize = tileSize;
		undred = new UndoRedo(this);
		try {
			imwall = ImageIO.read(new File("test/test/graphics/wall.jpg"));
			imbox = ImageIO.read(new File("test/test/graphics/box.jpg"));
			imfloor = ImageIO.read(new File("test/test/graphics/floor.jpg"));
			imgoal = ImageIO.read(new File("test/test/graphics/goal.jpg"));
			implayer = ImageIO.read(new File("test/test/graphics/player.jpg"));
			br = new BufferedReader(new FileReader(s));
			Scanner sc = new Scanner(new FileReader(s));
			int max = 0;
			mapWidth = 0;
			while (sc.hasNextLine()) {
				int test = sc.nextLine().length();
				mapHeight++;
				max = test;
				if (max >= mapWidth) {
					max++;
					mapWidth = max - 1;
				}
			}

			sc.close();
			map = new String[mapHeight][mapWidth];
			pl = new Player(this);
			for (int row = 0; row < mapHeight; row++) {
				String line = br.readLine();
				String[] tokens = line.split("", -1);
				for (int col = 0; col < mapWidth; col++) {
					map[row][col] = tokens[col];
					if (map[row][col].equals(".") || map[row][col].equals("*")) {
						goal = new Goal(this);
						goal.setx(row);
						goal.sety(col);
						goals.add(goal);
					}

				}
			}
		} catch (Exception e) {
		}
	}

	public boolean isComplete() {
		return complete;
	}
	/** Get tilesize **/
	public int getTileSize() {
		return tileSize;
	}

	public void update() {

	}
	/** Draw the tile map **/
	public void draw(Graphics2D g) {
		int test = 0;
		for (Goal go : goals) {
			if (map[go.getx()][go.gety()].equals(" ")) {
				map[go.getx()][go.gety()] = ".";
			} else if (map[go.getx()][go.gety()].equals("$")
					|| map[go.getx()][go.gety()].equals("*")) {
				test++;
			} else {
			}

		}
		if (test == goals.size()) {
			complete = true;
		}
		for (int row = 0; row < mapHeight; row++) {
			for (int col = 0; col < mapWidth; col++) {
				String rc = map[row][col];
				if (rc.equals("#")) {
					g.drawImage(imwall, col * tileSize, row * tileSize, null);
				}
				if (rc.equals(" ")) {

					g.drawImage(imfloor, col * tileSize, row * tileSize, null);
				}
				if (rc.equals("@")) {
					pl.setx(row);
					pl.sety(col);
					pl.draw(g, implayer);
				}
				if (rc.equals(".")) {
					goal = new Goal(this);
					goal.setx(row);
					goal.sety(col);
					goal.draw(g, imgoal);
				}
				if (rc.equals("$") || rc.equals("*")) {
					box = new Box(this);
					box.setx(row);
					box.sety(col);
					box.draw(g, imbox);
				}
			}
		}
	}
/** Moves player/box up **/
	public void moveUp() {
		String temp = map[pl.getx() - 1][pl.gety()];				//Swaping variables
		if (map[pl.getx() - 1][pl.gety()].equals(" ")) {
			map[pl.getx() - 1][pl.gety()] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = temp;
			if (add) {
				undred.addUndo("up");
			}
		} else if (map[pl.getx() - 1][pl.gety()].equals(".")) {
			map[pl.getx() - 1][pl.gety()] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = " ";
			if (add) {
				undred.addUndo("up");
			}

		} else if (map[pl.getx() - 1][pl.gety()].equals("$")
				|| map[pl.getx() - 1][pl.gety()].equals("*")) {
			if (!map[pl.getx() - 2][pl.gety()].equals("#")
					&& !map[pl.getx() - 2][pl.gety()].equals("$")) {
				temp = map[pl.getx()][pl.gety()];
				map[pl.getx() - 2][pl.gety()] = map[pl.getx() - 1][pl.gety()];
				map[pl.getx() - 1][pl.gety()] = temp;
				map[pl.getx()][pl.gety()] = " ";
				if (add) {
					undred.addUndo("upbox");
				}
			}
		}
	}
	/** Moves player/box down **/
	public void moveDown() {
		String temp = map[pl.getx() + 1][pl.gety()];
		if (map[pl.getx() + 1][pl.gety()].equals(" ")) {
			map[pl.getx() + 1][pl.gety()] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = temp;
			if (add) {
				undred.addUndo("down");
			}
		} else if (map[pl.getx() + 1][pl.gety()].equals(".")) {
			map[pl.getx() + 1][pl.gety()] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = " ";
			if (add) {
				undred.addUndo("down");
			}
		} else if (map[pl.getx() + 1][pl.gety()].equals("$")
				|| map[pl.getx() + 1][pl.gety()].equals("*")) {
			if (!map[pl.getx() + 2][pl.gety()].equals("#")
					&& !map[pl.getx() + 2][pl.gety()].equals("$")) {
				temp = map[pl.getx()][pl.gety()];
				map[pl.getx() + 2][pl.gety()] = map[pl.getx() + 1][pl.gety()];
				map[pl.getx() + 1][pl.gety()] = temp;
				map[pl.getx()][pl.gety()] = " ";
				if (add) {
					undred.addUndo("downbox");
				}
			}
		}
	}
	/** Moves player/box right **/
	public void moveRight() {
		String temp = map[pl.getx()][pl.gety() + 1];
		if (map[pl.getx()][pl.gety() + 1].equals(" ")) {
			map[pl.getx()][pl.gety() + 1] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = temp;
			if (add) {
				undred.addUndo("right");
			}
		} else if (map[pl.getx()][pl.gety() + 1].equals(".")) {
			map[pl.getx()][pl.gety() + 1] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = " ";
			if (add) {
				undred.addUndo("right");
			}
		} else if (map[pl.getx()][pl.gety() + 1].equals("$")
				|| map[pl.getx()][pl.gety() + 1].equals("*")) {
			if (!map[pl.getx()][pl.gety() + 2].equals("#")
					&& !map[pl.getx()][pl.gety() + 2].equals("$")) {
				temp = map[pl.getx()][pl.gety()];
				map[pl.getx()][pl.gety() + 2] = map[pl.getx()][pl.gety() + 1];
				map[pl.getx()][pl.gety() + 1] = temp;
				map[pl.getx()][pl.gety()] = " ";
				if (add) {
					undred.addUndo("rightbox");
				}
			}
		}
	}
	/** Moves player/box left **/
	public void moveLeft() {
		String temp = map[pl.getx()][pl.gety() - 1];
		if (map[pl.getx()][pl.gety() - 1].equals(" ")) {
			map[pl.getx()][pl.gety() - 1] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = temp;
			if (add) {
				undred.addUndo("left");
			}
		} else if (map[pl.getx()][pl.gety() - 1].equals(".")) {
			map[pl.getx()][pl.gety() - 1] = map[pl.getx()][pl.gety()];
			map[pl.getx()][pl.gety()] = " ";
			if (add) {
				undred.addUndo("left");
			}
		} else if (map[pl.getx()][pl.gety() - 1].equals("$")
				|| map[pl.getx()][pl.gety() - 1].equals("*")) {
			if (!map[pl.getx()][pl.gety() - 2].equals("#")
					&& !map[pl.getx()][pl.gety() - 2].equals("$")) {
				temp = map[pl.getx()][pl.gety()];
				map[pl.getx()][pl.gety() - 2] = map[pl.getx()][pl.gety() - 1];
				map[pl.getx()][pl.gety() - 1] = temp;
				map[pl.getx()][pl.gety()] = " ";
				if (add) {
					undred.addUndo("leftbox");
				}
			}
		}

	}
	/** Use undo method **/
	public void useUndo() {
		undred.useUndo();

	}
	/** Use redo method **/
	public void useRedo() {
		undred.useRedo();
	}
	/** Updating the map **/
	public void updateMap(String move) {
		if (move.equals("leftbox")) {
			map[pl.getx()][pl.gety() - 1] = " ";
			map[pl.getx()][pl.gety()] = "$";
			map[pl.getx()][pl.gety() + 1] = "@";

		}
		if (move.equals("left")) {
			moveRight();
		}
		if (move.equals("rightbox")) {
			map[pl.getx()][pl.gety() + 1] = " ";
			map[pl.getx()][pl.gety()] = "$";
			map[pl.getx()][pl.gety() - 1] = "@";

		}
		if (move.equals("right")) {
			moveLeft();
		}
		if (move.equals("upbox")) {
			map[pl.getx() - 1][pl.gety()] = " ";
			map[pl.getx()][pl.gety()] = "$";
			map[pl.getx() + 1][pl.gety()] = "@";

		}
		if (move.equals("up")) {
			moveDown();
		}
		if (move.equals("downbox")) {
			map[pl.getx() + 1][pl.gety()] = " ";
			map[pl.getx()][pl.gety()] = "$";
			map[pl.getx() - 1][pl.gety()] = "@";

		}
		if (move.equals("down")) {
			moveUp();
		}
	}

	private void add() {
		add = true;
	}
	/** Return redo stack **/
	public Stack<String> getRedo() {
		return undred.getRedo();
	}
	/** Clear redo stack **/
	public void clearRedo() {
		undred.clearRedo();
	}

	@Override
	public String toString() {
		String dimensions = mapWidth + "\n" + mapHeight + "\n";
		String a = "";
		for (String[] row : map) {
			for (String character : row) {
				a += character;
			}
			a = a + "\n";
		}

		return dimensions + a;
	}

	public void setAssistant(Assistant assist) {
		this.assist = assist;
	}
	/** Use Assistant **/
	public void useAssistant() {
		System.out.println(assist.dir.toString());
		if (!assist.dir.isEmpty()) {
			Direction move = assist.dir.pop();
			if (move == Direction.LEFT) {
				moveLeft();
			}
			if (move == Direction.DOWN) {
				moveDown();
			}
			if (move == Direction.RIGHT) {
				moveRight();
			}
			if (move == Direction.UP) {
				moveUp();
			}
		}
	}
}

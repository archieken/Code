/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The Box class creates a new Box object.
 * 
 * @author Group5 
 * @version 5/3/2016
 */

package test;

import java.awt.*;

public class Box {
	private int x;
	private int y;
	private TileMap tileMap;
	private int tileSize;

	/** Box constructor **/
	public Box(TileMap tl) {
		tileMap = tl;
		tileSize = tl.getTileSize();
	}

	public void setx(int x) {
		this.x = x;
	}

	public void sety(int y) {
		this.y = y;
	}

	/**
	 *return x 
	 */
	public int getx() {
		return x;
	}
	/**
	 *return y 
	 */
	public int gety() {
		return y;
	}
	/** Draw method**/
	public void draw(Graphics2D g, Image imbox) {
		g.drawImage(imbox, y * tileSize, x * tileSize, null);

	}

}

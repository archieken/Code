package test;

import java.util.HashSet;

public class State {

	private HashSet<Position> boxes;
	private Position player;

	public Position getPlayer() {
		return player;
	}

	public HashSet<Position> getBoxes() {
		return boxes;
	}

	public State(HashSet<Position> boxes, Position player) {
		this.boxes = boxes;
		this.player = player;
	}

	@Override
	public int hashCode() {
		int result = 17;
		for (Position box : boxes)
			result = 37 * result + box.hashCode();
		return 37 * result + player.hashCode();
	}

	@Override
	public boolean equals(Object that) {
		if (that == null)
			return false;
		if (that == this)
			return true;
		if (this.getClass() != that.getClass())
			return false;
		State thatState = (State) that;
		if (this.hashCode() == thatState.hashCode())
			return true;
		if ((this.boxes == thatState.boxes)
				&& (this.player == thatState.player))
			return true;
		return false;
	}

}
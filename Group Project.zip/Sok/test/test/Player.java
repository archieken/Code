/**
 * This class is part of the "Software Engineering with Group Project" Sokoban application.
 * 
 * The Player class creates a new Player object.
 * 
 * @author Group5 
 * @version 5/3/2016
 */
package test;

import java.awt.*;

public class Player {
	private int x;
	private int y;
	private TileMap tileMap;
	private int tileSize;
	
	/** Player constructor **/
	public Player(TileMap tl) {
		tileMap = tl;
		tileSize = tl.getTileSize();
	}


	public void setx(int x) {
		this.x = x;
	}

	public void sety(int y) {
		this.y = y;
	}
	/**
	 *return x 
	 */
	public int getx() {
		return x;
	}
	/**
	 *return y 
	 */
	public int gety() {
		return y;
	}
	/** Draw method**/
	public void draw(Graphics2D g, Image implayer) {
		g.drawImage(implayer, y * tileSize, x * tileSize, null);
	}

}

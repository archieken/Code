function validate() {
    
    /**Variables that keep track of the score and errors.**/
    var score=0;
    var error ="";
   
   /**Checks to see if text has been entered into the name box. Adds the warning string to the error variable. And highlights the name box yellow if no text has been entered.**/
    var name= document.forms[0].UserInfo.value.length;
    if(name==0) {
        error = error + " \n Please enter a name.";
        document.forms[0].UserInfo.style.backgroundColor="yellow";
    }
      
    /**Checks to see if a box has been selected for Question 1.  Adds the warning string to the error variable. And highlights Question 1 if none of the anwsers have been selected. If the answer is correct a point is added to the score variable. **/   
    
    var answerOne = document.forms[0].Q1.value;
    if (answerOne == "") {
        error = error + " \n For question 1 - please select a box.";
        document.getElementById("Q1").style.backgroundColor="yellow"; 
        }
        if (answerOne == "c")
        {
             score ++;
        }
        
    /**Checks to see if which of the for boxs have been selected. If a box has been selected a number is added to the count variable. If a box with the correct answer has been selected a point is added to the score variable. **/
        var count = 0;
    if (document.forms[0].Q2a.checked)
    {
        count ++;
        score ++;
        }
     if (document.forms[0].Q2b.checked)
    {
        count ++;
    }
     if (document.forms[0].Q2c.checked)
    {
        count ++;
        score ++;
    }
     if (document.forms[0].Q2d.checked)
    {
        count ++;
        }
        
        /**If more than two boxes have been selected a warning is added to the error variable. And highlights Question 2.**/ 

        if (count>2)
        {
             error = error + " \n For question 2 - you have selected too many boxes.";
             document.getElementById("Q2").style.backgroundColor="yellow"; 
        }
        
         /**If less than two boxes have been selected and warning is added to the error variable And highlights Question 2.**/
        
        if (count<2)
        {
        error = error + "\n For question 2 - please select two boxes.";
        document.getElementById("Q2").style.backgroundColor="yellow"; 
        }


     /**Create boolean variables for each answer. If a box has been selected the answer will equal true.**/
    var ThreeA = document.forms[0].Q3a.checked;
    var ThreeB = document.forms[0].Q3b.checked;
    var ThreeC =document.forms[0].Q3c.checked;
   var ThreeD =document.forms[0].Q3d.checked;
    
    /**If all the answers are false meaning none of the boxes have been selected. A warning is added to the error variable and Question 3 is highlighted yellow.**/
    
   if (!ThreeA & !ThreeB & !ThreeC & !ThreeD) {
    error = error + "\n For question 3 - please select a box.";
    document.getElementById("Q3").style.backgroundColor="yellow"; 
    }
    if (ThreeB) {
  score ++;
    }
    
    /**Checks to see if text has been entered for Question 4. If no text has been entered
      a warning is added to the error variable and Question 4 is highlighted yellow. If the answer is correct a point is added to the score variable. 
    **/   
    var answerFour= document.forms[0].Q4.value;
       if(answerFour=="") {
        error = error + "\n For question 4 - please enter an answer.";
        document.getElementById("Q4").style.backgroundColor="yellow"; 
    }
    
    /**converts all text to lowercase. Making it case insensitive**/
     var answerFourLower = answerFour.toLowerCase();  
    if (answerFourLower=="vexillology") {
        score ++;
     } 
      
     /** If anything has been added to the error variable, show the user the errors and return false stoping the form from being sent to the php. **/
     if(error.length!=0){
        error=error.substr(0,error.length-1);
        alert(error);
        return false;
    }

        /** If no errors have been found. An alert appears show the user the score.**/
    else{
       alert("Score: "+ score + " \n \nYour answers and score are now being sent to the server.");
    }
    /** Score variable is assigned to this score and results are sent to php**/
    document.forms[0].thisScore.value = score;
    return true;
    }